#ifndef FAIL_TESTS_H
#define FAIL_TESTS_H

int fail_tests();

#endif
